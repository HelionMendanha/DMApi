<?php 
ini_set('memory_limit', '1024M');
//ini_set('memory_limit', '-1');
set_time_limit(0);
require_once 'vendor/autoload.php';
require_once 'Db.php';
header('Content-Type: application/json; charset=utf-8');
$_TimeInit = microtime();

$arr = [
    'error'  => true,
    'msg'    => 'Não processado',
    'fields' => [],
    'time'   => 0,
    'memory' => [round(memory_get_usage()/1048576,2)." mb"],
    'POST'   => $_POST,
    'GET'    => $_GET
];

function diff_microtime( $mt_old, $mt_new ){

    list($old_usec, $old_sec) = explode( ' ', $mt_old );
    list($new_usec, $new_sec) = explode( ' ', $mt_new );
    $old_mt = ((float)$old_usec + (float)$old_sec);
    $new_mt = ((float)$new_usec + (float)$new_sec);
    return $new_mt - $old_mt;
}

