<?php
require_once 'loader.php';

/*
$_GET['srtconn']  = 'mongodb://helion:mipasswordi8o9p0@rc_qa_db_27020:27017/admin?retryWrites=true&w=majority';
$_GET['srtconn']  = 'mongodb://helion:mipasswordi8o9p0@10.63.0.3:27020/admin?retryWrites=true&w=majority';
$_GET['database'] = 'rocketchat';
$_GET['find']     = '{"collection":"municipios","find":{"munic_coduf":"31"},"options":{"projection":{"munic_id":1,"munic_coduf":1,"_id":0,"munic_nome":1},"limit":15}}';
*/

try {
    
    $objDb = new Db();
    
    if (empty($_GET['srtconn'])) {
        
        throw new Exception('Api mongodb: "srtconn" não definida!');
    }

    if (empty($_GET['database'])) {

        throw new Exception('Api mongodb: parâmetro get "database" não definido!');
    }

    $databases = $objDb->listDatabases($_GET['srtconn']);

    if (!in_array($_GET['database'], $databases)) {

        throw new Exception('Api mongodb: a database "' . $_GET['database'] . '" não existe!');
    }

    if (empty($_GET['find'])) {

        throw new Exception('Api mongodb: parâmetro get "find" não definido!');
    }

    $find = json_decode($_GET['find'], true);

    $arr['database'] = $_GET['database'];
    $arr['find'] = $find;

	$paramFind = (empty($find['find']) ? array() : $find['find'] );
	$paramOptions = (empty($find['options']) ? array() : $find['options'] );

    if (empty($find)) {

        throw new Exception('Api mongodb: invalid syntax json query');
    }

    // Query = '{"datamapping": 1}'
    if (empty($find["datamapping"])) {

        // {"collection":"users","find":{"username":"3536"},"fields":{"username":1,"name":1,"_id":1,"type":1}}
        if (empty($find["collection"])) {

            throw new Exception('Api mongodb: "collection" não definida em json query');
        }

        $collections = $objDb->listCollections($_GET['srtconn'], $_GET['database']);
        if (!in_array($find["collection"], $collections)) {
            
            throw new Exception('Api mongodb: collection "' . $find["collection"] . '" não existe na database "' . $_GET['database'] .'"!');
        }

        $arr['fields'] = $objDb->find($_GET['srtconn'], $_GET['database'] , $find["collection"], $paramFind , $paramOptions );
    }else{

        $arr['fields'] = $objDb->datamapping($_GET['srtconn'], $_GET['database']);
    }
    
    $arr['error'] = false;
    $arr['msg'] = 'Sucesso';
} catch (Exception $e) {

    $arr['error'] = true;
    $arr['msg'] = 'Api mongodb: '.$e->getMessage();
}

$arr['memory'][] = round(memory_get_usage()/1048576,2)." mb"; 

$arr['time'] = number_format( diff_microtime( $_TimeInit, microtime() ), 4 );

$http_code = http_response_code();

$json =  json_encode($arr);
echo $json;
