<?php
require_once 'loader.php';

try {
    
    $objDb = new Db();
    
    if (empty($_POST['srtconn'])) {

        throw new Exception('"srtconn" não definida!');
    }

    if (!empty($_POST['database'])) {

        $databases = $objDb->listDatabases($_POST['srtconn']);

        if (!in_array($_POST['database'], $databases)) {

            throw new Exception('A database "' . $_POST['database'] . '" não existe!');
        }
    }

    $arr['databases'] = $objDb->listDatabases( $_POST['srtconn'] );
    $arr['error'] = false;
    $arr['msg'] = 'Sucesso';
} catch (Exception $e) {

    $arr['error'] = true;
    $arr['msg'] = $e->getMessage();
}

$arr['memory'][] = round(memory_get_usage()/1048576,2)." mb"; 

$arr['time'] = number_format( diff_microtime( $_TimeInit, microtime() ), 4 );
$json =  json_encode($arr);
echo $json;
