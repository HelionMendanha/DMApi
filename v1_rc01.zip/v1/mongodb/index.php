<?php

$strBaseUrl = str_replace('/index.php', '', $_SERVER["SCRIPT_NAME"]);
$strUriParam = str_replace($strBaseUrl, '', $_SERVER["REQUEST_URI"]);
$arrParametros = explode('?', $strUriParam);
$arrUriParam = explode('/', $arrParametros[0]);

$strPagina = $arrUriParam[1];

if (empty($strPagina)) {
    $strPagina = 'datamapping';
}

if (file_exists(($strPagina . '.php'))) {
    include ($strPagina . '.php');
} else {
    header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found", true, 404);
    include '404.php';
    exit;
}


