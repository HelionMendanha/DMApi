<?php
class Db {
    
    protected $_conn;
    protected $_dmfields = [];
    protected $_objTypes = [];
    protected $_currentField;
    protected $_datamappingSample = 5; // Quantidade de amostra de dados para DataMapping
    
    public function listDatabases($dsn) {

        try {

            $this->connect($dsn);

            $dbs = [];
            foreach ($this->_conn->listDatabases() as $database) {
                $dbs[] = $database->getName();
            }
            return $dbs;
        } catch (MongoDB\Driver\Exception\Exception $e) {

            $msg = $e->getMessage();
            throw new Exception($msg);
        }
    }

    public function datamapping($dsn, $databaseName) {

        try {

            $debug = false;
			
            $collectionNames = $this->listCollections($dsn, $databaseName);
			
            $datamapping = array();
            foreach ($collectionNames as $collectionName) {
                
              
                $collectionName = ( $debug ? 'users' : $collectionName);
                $countColl = $this->countCollection($dsn, $databaseName, $collectionName);
                $amostra   = $this->findAmostraMappingCollection($dsn, $databaseName, $collectionName);
                
                $dm0 = [
                           'database'   => $databaseName,
                           'collection' => $collectionName,
                           'count'      => $countColl,
                        ];
       
                if($debug){
					
					$fields = $this->mapper([] /* $dm0 */, $amostra);
                    $dm0['types']  = $this->_objTypes;
                    $dm0['fields'] = $fields;
                
                    $datamapping[] = $dm0;
                    break;
                }else{
                    
                    $dmColl = $this->mapper($dm0, $amostra);
                    $datamapping = ( count($datamapping) == 0 ? $dmColl : array_merge($datamapping, $dmColl ) );
					
                }
                
            }
            return [ 'ObjTypes' => $this->_objTypes, 'fields' => $datamapping];
            
        } catch (MongoDB\Driver\Exception\Exception $e) {

            $msg = $e->getMessage();
            throw new Exception($msg);
        }
    }
	
    private function mapper($mapperBase, $amostra) {

        $this->_dmfields = array();
        
        foreach ($amostra as $key => $doc) {
           
            $this->mapperLevel0($doc, $mapperBase);
        }
        
        
//        if(!empty($this->_dmfields)){
//            
//            $json =  json_encode($this->_dmfields);
//            echo $json;
//            die();
//        }
        
        $mapperFields = [];
        foreach ($this->_dmfields as $key => $value) {
            
            $aField = ['field' => $key, 'type' => $value['type'], 'class' => $value['class'] ];
            $mapperFields[] = array_merge($mapperBase, $aField );
        }
        
        // http://localhost/api_lgpdnow/v1/mongodb/test1
        return $mapperFields;
       
    }
    
    private function mapperLevel0($amostra, $mapperBase) {

        foreach ($amostra as $key => $doc) {

            $chave = '"' . $key . '"';
            $current = $chave;
            $type = gettype($doc);
            
            $class = ( $type == 'object' ? get_class($doc) : '#');
			if($type == 'object' && $class == 'MongoDB\BSON\ObjectId'){
                
                $this->_dmfields[$current] = ['type' => 'String', 'class' => $class];
            }else if($type == 'object' && $class == 'MongoDB\BSON\UTCDateTime'){
				
				$this->_dmfields[$current] = ['type' => 'DateTime', 'class' => $class];
            }else if($type == 'object' && $class == 'MongoDB\BSON\Binary'){
                
				$this->_dmfields[$current] = ['type' => 'Binary', 'class' => $class];
            }else if($type == 'object' ){
                    
                $this->_objTypes[$class] = $class;
                $this->_current = $current;
                $this->mapperChildrens($doc, $mapperBase);
                
            }else{
                
                $this->_dmfields[$current] = ['type' =>  $type, 'class' => $class];
            }
        }
     
        return true;
    }
    
    private function mapperChildrens($amostra) {

        foreach ($amostra as $key => $doc) {
            
            $chave = '"' . $key . '"';
            $current = $this->_current.'.'.$chave;
            
            $type = gettype($doc);
            
            $class = ( $type == 'object' ? get_class($doc) : '#');
            if($type == 'object' && $class == 'MongoDB\BSON\ObjectId'){
                
                $this->_dmfields[$current] = ['type' => 'String', 'class' => $class];
            }else if($type == 'object' && $class == 'MongoDB\BSON\UTCDateTime'){
                
                $this->_dmfields[$current] = ['type' => 'DateTime', 'class' => $class];
            }else if($type == 'object' && $class == 'MongoDB\BSON\Binary'){
                
				$this->_dmfields[$current] = ['type' => 'Binary', 'class' => $class];
            }else if($type == 'object' ){
                
                $this->_objTypes[$class] = $class;
                $this->_current = $current;
                $this->mapperChildrens($doc);
            }else{
                
                $this->_dmfields[$current] = ['type' => $type, 'class' => $class];
            }
        }
        
        return true;
    }
    
    private function findAmostraMappingCollection($dsn, $databaseName, $collectionName) {

        try {

            $this->connect($dsn);

            $db = $this->_conn->selectDatabase($databaseName);
            $collection = $db->selectCollection($collectionName);
                
            $search = [];
            $options= ['limit' => $this->_datamappingSample];
            
            $cursor = $collection->find($search, $options);
            
            return $cursor->toArray();
            
        } catch (MongoDB\Driver\Exception\Exception $e) {

            $msg = $e->getMessage();
            throw new Exception($msg);
        }
    }
	
    public function find($dsn, $databaseName, $collectionName, $search, $options = array() ) {

        try {

            $this->connect($dsn);

            $db = $this->_conn->selectDatabase($databaseName);
            $collection = $db->selectCollection($collectionName);


            $cursor = $collection->find($search, $options);
            

            return $cursor->toArray();
            
        } catch (MongoDB\Driver\Exception\Exception $e) {

            $msg = $e->getMessage();
            throw new Exception($msg);
        }
    }
    private function countCollection($dsn, $databaseName, $collectionName) {

        try {

            $this->connect($dsn);

            $db = $this->_conn->selectDatabase($databaseName);
            $collection = $db->selectCollection($collectionName);
                
            $search = [];
            $options= [];
            
            $cursor = $collection->countDocuments($search, $options);
         
            return $cursor; 
            
        } catch (MongoDB\Driver\Exception\Exception $e) {

            $msg = $e->getMessage();
            throw new Exception($msg);
        }
    }
	
    public function listCollections($dsn, $databaseName) {

        try {

            $this->connect($dsn);

            $db = $this->_conn->selectDatabase($databaseName);
            $collections = $db->listCollections();

            $colls = [];
            foreach ($collections as $collection) {
                $colls[] = $collection->getName();
            }
			sort($colls);
            return $colls;
			
        } catch (MongoDB\Driver\Exception\Exception $e) {

            $msg = $e->getMessage();
            throw new Exception($msg);
        }
    }
	
    private function connect($dsn) {

        if ($this->_conn) {
            return $this->_conn;
        }
        
        try {

            $this->_conn = new MongoDB\Client($dsn);
            
        } catch (MongoDB\Driver\Exception\Exception $e) {

            $msg = $e->getMessage();
            throw new Exception($msg);
        }
    }
}
