<?php
require_once 'loader.php';

/*
$_GET['srtconn']  = 'mongodb://helion:mipasswordi8o9p0@rc_qa_db_27020:27017/admin?retryWrites=true&w=majority';
$_GET['srtconn']  = 'mongodb://helion:mipasswordi8o9p0@10.63.0.3:27020/admin?retryWrites=true&w=majority';
$_GET['database'] = 'rocketchat';
*/

try {
    
    $objDb = new Db();
    
    if (empty($_GET['srtconn'])) {
        
        throw new Exception('Api mongodb: o parâmetro get "srtconn" não foi definido!');
    }


    if (empty($_GET['database'])) {

        throw new Exception('Api mongodb: o parâmetro get "database" não foi definido!');
    }

    if (empty($_GET['field'])) {

        throw new Exception('Api mongodb: o parâmetro get "field" não foi definido!');
    }

    $databases = $objDb->listDatabases($_GET['srtconn']);

    if (!in_array($_GET['database'], $databases)) {

        throw new Exception('Api mongodb: a database "' . $_GET['database'] . '" não existe!');
    }

	$aDm =  $objDb->datamapping($_GET['srtconn'], $_GET['database'], $_GET['field']);
	$arr['types'] = $aDm['ObjTypes'];
	$arr['dados']  = $aDm['dados'];
	
    $arr['error'] = false;
    $arr['msg'] = 'Sucesso';
} catch (Exception $e) {

    $arr['error'] = true;
    $arr['msg'] = $e->getMessage();
}

$arr['memory'][] = round(memory_get_usage()/1048576,2)." mb"; 

$arr['time'] = number_format( diff_microtime( $_TimeInit, microtime() ), 4 );

$http_code = http_response_code();

$json =  json_encode($arr);
echo $json;
